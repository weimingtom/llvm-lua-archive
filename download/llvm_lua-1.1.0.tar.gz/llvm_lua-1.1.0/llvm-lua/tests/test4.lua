local a = 1
local b = 2
local c
if a > b then
	c = a
else
	c = b
end
print(c)
