local a = "1" + 2
local b = 1
local c = 2
local d = b + 2
local e = 1 + c
local f = b + c
print(a,b,c,d,e,f)
