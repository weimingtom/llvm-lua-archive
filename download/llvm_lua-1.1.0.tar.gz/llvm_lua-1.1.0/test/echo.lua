-- echo command line arguments

for i=0,#arg do
 print(i,arg[i])
end
