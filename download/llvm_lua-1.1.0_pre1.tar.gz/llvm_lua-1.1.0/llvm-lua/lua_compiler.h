
#ifndef lua_compiler_h
#define lua_compiler_h

#ifdef __cplusplus
extern "C" {
#endif

#include "lua_core.h"

extern int luac_main(int argc, char **argv);

#ifdef __cplusplus
}
#endif

#endif

