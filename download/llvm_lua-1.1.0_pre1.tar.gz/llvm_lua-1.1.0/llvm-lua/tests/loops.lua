
local x = 0
for a=1,25 do
	x = x + 1
end
for b=1,25 do
	x = x + 1
end
for c=1,25 do
	x = x + 1
end
for d=1,25 do
	x = x + 1
end
for e=1,25 do
	x = x + 1
end
for f=1,25 do
	x = x + 1
end
--print(a,",",b,",",c,",",d,",",e,",",f,",",x,"\n")
io.write(x,"\n")
