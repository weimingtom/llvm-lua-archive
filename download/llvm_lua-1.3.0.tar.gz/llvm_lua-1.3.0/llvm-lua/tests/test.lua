
local i
local count=0

for i=1,100000000 do
	count = count + 1
end

print(count)
