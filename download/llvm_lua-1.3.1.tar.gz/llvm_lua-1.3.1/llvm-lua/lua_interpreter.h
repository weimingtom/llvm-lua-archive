
#ifndef lua_interpreter_h
#define lua_interpreter_h

#ifdef __cplusplus
extern "C" {
#endif

extern int lua_main(int argc, char **argv);

#ifdef __cplusplus
}
#endif

#endif

