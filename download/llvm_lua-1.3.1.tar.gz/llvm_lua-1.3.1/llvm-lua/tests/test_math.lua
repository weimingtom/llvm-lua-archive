
local sqrt=math.sqrt
local a

for n=1,1000000 do
--for n=1,10000 do
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
	a=sqrt(9)
end

print("a=",a)
print("pow(3,3)=", math.pow(3,2))
print("abs(-3.6)=", math.abs(-3.6))

-- test tailcall of math.* function
local function floor(num)
	return math.floor(num)
end

print("floor(1.2345)=", floor(1.2345))

