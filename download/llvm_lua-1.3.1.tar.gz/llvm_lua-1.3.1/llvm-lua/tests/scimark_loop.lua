
local n = 100
local test = function()
		for i=1,n*2 do
print(i)
		end
end

test(100)

