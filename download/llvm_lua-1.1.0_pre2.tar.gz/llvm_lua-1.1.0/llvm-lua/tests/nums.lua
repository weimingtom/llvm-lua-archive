local a=5
local b=6
local c=7
local d=8
a = a + 9
b = b - 10
c = c * 11
d = d / 12
print(a,b,c,d)
