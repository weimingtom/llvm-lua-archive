print(unpack(arg))
local n = tonumber((arg and arg[1]) or 1)
io.write(n,"\n")
