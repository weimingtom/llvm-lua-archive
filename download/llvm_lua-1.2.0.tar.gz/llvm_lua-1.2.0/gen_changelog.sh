#!/bin/sh
#

svn2cl --authors=AUTHORS --break-before-msg --group-by-day -o ChangeLog

